1) افتح license_tool.html ← "تجهيز نسخة التطبيق" ← اختر generator_app.html ← سينزل generator_app_licensed.html
2) استبدل الملف www/index.html بهذا الملف المجهّز (غيّر اسمه إلى index.html)
3) ارفع كل محتويات هذا المجلد (بما فيها المجلد المخفي .github) إلى مستودع GitHub *خاص* (Private)
4) تبويب Actions ← Build APK ← Run workflow ← بعد دقائق نزّل الملف generator-apk من الأسفل (Artifacts)
